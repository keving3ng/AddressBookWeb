package com.AddressBook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AddressBook5Application {

	public static void main(String[] args) {
		SpringApplication.run(AddressBook5Application.class, args);
	}

}
