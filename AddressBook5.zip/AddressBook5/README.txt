Start with /addressBook

Add an addressbook, then the form can be used to add a buddy, or return to main page

Use [GET AddressBook(s)] button to see the jquery script in action on the REST endpoint.
